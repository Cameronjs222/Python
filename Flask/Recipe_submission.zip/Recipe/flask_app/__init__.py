from flask import Flask
app = Flask(__name__)
app.secret_key = "I'm going to be king of the pirates"